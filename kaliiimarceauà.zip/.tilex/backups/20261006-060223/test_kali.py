#!/usr/bin/env python3
# test_kali.py

import os
import subprocess
import sys

def run_command(command):
    try:
        result = subprocess.run(command, shell=True, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        return result.stdout.decode('utf-8')
    except subprocess.CalledProcessError as e:
        return f"Error: {e.stderr.decode('utf-8')}"

def test_network():
    print("Starting network test...")
    result = run_command("ping -c 4 127.0.0.1")
    print("Network test result:")
    print(result)

def test_disk_space():
    print("Starting disk space test...")
    result = run_command("df -h")
    print("Disk space test result:")
    print(result)

def test_python_version():
    print("Starting Python version test...")
    result = run_command("python3 --version")
    print("Python version test result:")
    print(result)

def test_top_10_kali_tools():
    print("Starting top 10 Kali Linux tools test...")
    result = run_command("ls /usr/share/kali-linux-tools | head -n 10")
    print("Top 10 Kali Linux tools test result:")
    print(result)

if __name__ == "__main__":
    print("Starting Kali Linux test suite...")
    test_network()
    test_disk_space()
    test_python_version()
    test_top_10_kali_tools()
    print("Kali Linux test suite completed.")