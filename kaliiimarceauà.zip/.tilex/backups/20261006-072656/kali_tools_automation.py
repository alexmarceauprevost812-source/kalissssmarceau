#!/usr/bin/env python3
# kali_tools_automation.py

import os
import subprocess
import sys

def run_command(command):
    try:
        result = subprocess.run(command, shell=True, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        return result.stdout.decode('utf-8')
    except subprocess.CalledProcessError as e:
        return f"Error: {e.stderr.decode('utf-8')}"

def menu_item_3_add_target():
    print("Starting network test...")
    result = run_command("ping -c 4 127.0.0.1")
    print("Network test result:")
    print(result)

def menu_item_4_execute_attacks():
    print("Starting disk space test...")
    result = run_command("df -h")
    print("Disk space test result:")
    print(result)

def menu_item_5_security_results():
    print("Starting Python version test...")
    result = run_command("python3 --version")
    print("Python version test result:")
    print(result)

def menu_item_6_find_device_secrets():
    print("Starting top 10 Kali Linux tools test...")
    result = run_command("ls /usr/share/kali-linux-tools | head -n 10")
    print("Top 10 Kali Linux tools test result:")
    print(result)

def test_ollama_model():
    print("Starting Ollama model test...")
    result = run_command("ollama --model tiny --prompt 'Hello, world!'")
    print("Ollama model test result:")
    print(result)

def test_ollama_chatbot():
    print("Starting Ollama chatbot test...")
    result = run_command("ollama --model chatbot --prompt 'Tell me a joke.'")
    print("Ollama chatbot test result:")
    print(result)

def test_ollama_translation():
    print("Starting Ollama translation test...")
    result = run_command("ollama --model translate --prompt 'Translate this to Spanish: Hello, world!'")
    print("Ollama translation test result:")
    print(result)

def test_ollama_summarization():
    print("Starting Ollama summarization test...")
    result = run_command("ollama --model summarize --prompt 'Summarize this text: Kali Linux is a Debian-based Linux distribution designed for digital forensics and penetration testing.'")
    print("Ollama summarization test result:")
    print(result)

def test_ollama_qa():
    print("Starting Ollama QA test...")
    result = run_command("ollama --model qa --prompt 'What is the capital of France?'")
    print("Ollama QA test result:")
    print(result)

def create_html_button():
    html_button = """
    <html>
    <head>
        <title>Auto Button</title>
    </head>
    <body>
        <button onclick="alert('Button clicked!')">Click Me</button>
    </body>
    </html>
    """
    with open("auto_button.html", "w") as file:
        file.write(html_button)
    print("HTML button created.")

if __name__ == "__main__":
    print("Starting Kali Linux test suite...")
    test_network()
    test_disk_space()
    test_python_version()
    test_top_10_kali_tools()
    test_ollama_model()
    test_ollama_chatbot()
    test_ollama_translation()
    test_ollama_summarization()
    test_ollama_qa()
    create_html_button()
    print("Kali Linux test suite completed.")